package com.revtaskmanagement.RevTask.Repository;

import com.revtaskmanagement.RevTask.Entity.ProjectDetail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectDetailRepository extends JpaRepository<ProjectDetail, Long> {
}
