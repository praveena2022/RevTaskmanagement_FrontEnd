INSERT INTO admin (username, password) VALUES ('admin1', 'password1');
INSERT INTO client (name, email) VALUES ('Client1', 'client1@example.com');
INSERT INTO project_manager (username, password) VALUES ('manager1', 'password1');
INSERT INTO team_member (username, password) VALUES ('member1', 'password1');


