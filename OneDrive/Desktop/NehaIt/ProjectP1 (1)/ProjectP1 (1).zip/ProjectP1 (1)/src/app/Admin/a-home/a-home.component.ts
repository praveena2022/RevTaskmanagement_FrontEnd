import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { project } from '../../admin-auth';


@Component({
  selector: 'app-a-home',
  templateUrl: './a-home.component.html',
  styleUrl: './a-home.component.css'
 
})
export class AHomeComponent {
  

  
}
