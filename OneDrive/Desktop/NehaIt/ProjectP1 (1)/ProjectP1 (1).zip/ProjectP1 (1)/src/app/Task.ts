// export interface Task {
//     id: number; // Optional, as it will be assigned by the backend
//     title: string;
//     description: string;
//     status: string; // 'assigned', 'inprogress', or 'completed'
//     priority: string; // 'high', 'medium', or 'low'
//     assignDate?: Date; // Optional, as it will be assigned by the backend
//     dueDate: Date;
//     assignedTo: number; // Assuming it's the ID of the assigned team member
//     projectId: number; // ID of the project
//   }