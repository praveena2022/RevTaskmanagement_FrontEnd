export interface AdminProjects{
    id:number;
    description:string;
    name:string;
}