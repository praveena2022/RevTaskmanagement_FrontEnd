
export interface UserDetails {
  id: number;
  email: string;
  // Add other properties as needed
}