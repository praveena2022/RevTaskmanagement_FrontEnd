import { Component, OnInit } from '@angular/core';

import { ClientService } from '../../client.service';
import { ProjectP, client } from '../../projectp';
import { ProjectServiceService } from '../../project.service.service';
import { PmAuthService } from '../../pm-auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-project',
  templateUrl: './create-project.component.html',
  styleUrls: ['./create-project.component.css']
})
export class CreateProjectComponent implements OnInit {
  project: ProjectP = {
    id: 0,
    name: '',
    description: '',
    clientName: '',
    dueDate: new Date(),
    assignedDate: new Date()
  };
  clients: client[] = [];
  showForm:boolean = false;

constructor(
    private projectService: ProjectServiceService,
    private clientService: ClientService,
    private pmAuthService:PmAuthService,
    private router: Router
 
  ) {}

ngOnInit(): void {
    this.clientService.getclients().subscribe(clients => {
      this.clients = clients;
    });

  }

// onSubmit(): void {
  //   // Assuming projectManagerId and projectManagerName are set here based on logged-in user
  //   const projectToSave = {
  //     ...this.project,
  //     dueDate: this.project.dueDate.toLocaleDateString,
  //     assignedDate: this.project.assignedDate.toDateString,
  //     projectManagerId: 1, // Replace with actual project manager ID
  //     projectManagerName: 'Project Manager' // Replace with actual project manager name
  //   };
  toggleFormVisibility(): void {
    this.showForm = !this.showForm;
  }
  
  onSubmit(): void {
    const projectToSave: ProjectP = {
      ...this.project,
      dueDate: new Date(this.project.dueDate),
      assignedDate: new Date(this.project.assignedDate),
    };
    // const userId=this.pmAuthService.getUserId();
    // console.log("this is pm user iD"+userId);
   
    const userEmail=this.pmAuthService.getEmail();

this.projectService.createProject(projectToSave,userEmail).subscribe(result => {
      console.log('Project created:', result);

});
  }
}

