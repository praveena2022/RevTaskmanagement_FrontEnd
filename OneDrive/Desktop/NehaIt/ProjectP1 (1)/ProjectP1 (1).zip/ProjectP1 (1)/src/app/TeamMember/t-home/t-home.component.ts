import { Component, OnInit } from '@angular/core';
// import { project } from '../../project';
import { ProjectService } from '../../project.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-t-home',
  templateUrl: './t-home.component.html',
  styleUrl: './t-home.component.css'
})
export class THomeComponent {
  
}
