export interface pmAuth{
    username:string;
    email:string;
    password:string
}