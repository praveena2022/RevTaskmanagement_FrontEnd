export interface MemberProjects{
    id: number;
    projectManagerName: String;
    description: String;
    clientName: String;
    name:string;
    projectManagerId:number;
}