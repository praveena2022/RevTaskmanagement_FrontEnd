export interface memAuth{
    username:string;
    email:string;
    password:string
}