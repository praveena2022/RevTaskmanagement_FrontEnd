export interface TeamMember {
    username: string;
    email: string;
    password: string;
    role:string;
  }
  