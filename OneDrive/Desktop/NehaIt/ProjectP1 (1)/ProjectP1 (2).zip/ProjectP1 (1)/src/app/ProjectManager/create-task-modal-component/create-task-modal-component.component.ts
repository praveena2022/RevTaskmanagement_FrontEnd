import { Component } from '@angular/core';

@Component({
  selector: 'app-create-task-modal-component',
  templateUrl: './create-task-modal-component.component.html',
  styleUrl: './create-task-modal-component.component.css'
})
export class CreateTaskModalComponentComponent {

}
